package com.dicoding.menirukanmu;

public class Payload {
    public Events[] events;
}
