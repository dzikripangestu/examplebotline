package com.dicoding.menirukanmu;

public class Source {
    public String userId;
    public String groupId;
    public String roomId;
    public String type;
}
